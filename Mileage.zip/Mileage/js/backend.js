function grabData(){
	var dataString = "";
	$.ajax({
				type: "GET",
				url: "http://localhost:8001/",
				data: dataString,
				cache: false,
				success: function(data) {
					rePresent(data);
				},
				error: function(data)
				{
					noti(4);
				}
		});
}

function grabData1(){
	var dataString = "";
	$.ajax({
				type: "GET",
				url: "http://localhost:8001/r",
				data: dataString,
				cache: false,
				success: function(data) {
					rePresent1(data);
				},
				error: function(data)
				{
					noti(4);
				}
		});
}

var useful=[];
function rePresent(data){
	for(var i=0;i<data.length-1;i++)
	{
		if(data[i]!=0)
		{
			useful.push({
				"val":data[i],
				"day": Math.floor(i/4) +1
			});
		}
	}
	//console.log(useful[0].val)
	displayData(useful);
}

var useful1=[];
function rePresent1(data){
	for(var i=0;i<data.length-1;i++)
	{
		if(data[i]!=0)
		{
			useful1.push({
				"val":data[i],
				"day": Math.floor(i/4) +1
			});
		}
	}
	//console.log(useful[0].val)
	displayData1(useful1);
}

function displayData1(useful1){
	var str = "";
	var arr = ["Sun", "Mon", "Tue", "Wed", "Thurs", "Fri", "Sat"];

	for(var i=0;i<useful1.length;i++)
	{
		str += arr[useful1[i].day-1] + " : " + useful1[i].val + " hrs --> "+ (useful1[i].val-1) +" hrs<br>";
	}
	document.getElementById("buslist2").innerHTML = str;
}

function displayData(useful){
	var str = "";
	var arr = ["Sun", "Mon", "Tue", "Wed", "Thurs", "Fri", "Sat"];

	for(var i=0;i<useful.length;i++)
	{
		str += arr[useful[i].day-1] + " : " + useful[i].val + " hours <br>";
	}
	document.getElementById("buslist1").innerHTML = str;
}

function checkLogin(){
	grabData();
	grabData1();
    if(!localStorage.userName)
	{
		document.getElementById('appLoginScreen').style.display="block";
	}
	else{
		document.getElementById('appMainScreen').style.display="block";
		if(localStorage.dataFlag!=1)
		{
			document.getElementById('getData').style.display="block";
			document.getElementById('showRisk').style.display="none";
		}
		else
		{	document.getElementById('getData').style.display="none";
			document.getElementById('showRisk').style.display="block";
			showStatus(localStorage.risk,localStorage.gender,localStorage.workout,localStorage.smoke);
		}
	}
	var w = window.innerWidth;
    var h = window.innerHeight;
    document.getElementById('appLoginScreen').style.height = h + "px";
    document.getElementById('appLoginScreen').style.width = w + "px";

     document.getElementById('appMainScreen').style.height = h + "px";
    document.getElementById('appMainScreen').style.width = w + "px";
    
}

var a=0;
function displayOptions() {
	if(a==0)
	{
		document.getElementById('lowerBar').style.display = "block";
	  document.getElementById('lowerBar').className = "lowerBar animated slideInUp";
		a++;
	}
	else {
		document.getElementById('lowerBar').className = "lowerBar animated slideOutDown";
		setTimeout(function(){
			document.getElementById('lowerBar').style.display = "none";
		},300);
		a--;
	}
}


function noti(code){

	if(code==1){
		document.getElementById('notitext').innerHTML = "Enter Data Again to Calculate Risk!";
		lebhai();
		document.getElementById('idk').src = "assets/images/suc.png";
		document.getElementById('noti').style.display = "block";
		document.getElementById('noti').className = "noti animated slideInRight";

		setTimeout(function(){
			document.getElementById('noti').className = "noti animated slideOutRight";
			setTimeout(function(){
				document.getElementById('noti').style.display = "none";
			},400);
		},5000);
	}

	else if (code==2) {
		document.getElementById('notitext').innerHTML = "Thanks for trying this app :) Do come back.";
		document.getElementById('idk').src = "assets/images/thanks.png";
		document.getElementById('noti').style.display = "block";
		document.getElementById('noti').className = "noti animated slideInRight";

		setTimeout(function(){
			document.getElementById('noti').className = "noti animated slideOutRight";
			localStorage.clear();
			setTimeout(function(){
				document.getElementById('noti').style.display = "none";
				window.location.href= window.location.href;
			},400);
		},2500);
	}

	else if (code==3) {
		document.getElementById('notitext').innerHTML = "Made in India with love. Team Mileage. Mileage Beta Version";
		document.getElementById('idk').src = "assets/images/india.png";
		document.getElementById('noti').style.display = "block";
		document.getElementById('noti').className = "noti animated slideInRight";

		setTimeout(function(){
			document.getElementById('noti').className = "noti animated slideOutRight";
			setTimeout(function(){
				document.getElementById('noti').style.display = "none";
			},400);
		},5000);
	}

	else if (code==4) {
		document.getElementById('notitext').innerHTML = "You are Offline. App requires Internet Connection";
		document.getElementById('idk').src = "assets/images/cellphone.png";
		document.getElementById('noti').style.display = "block";
		document.getElementById('noti').className = "noti animated slideInRight";

		setTimeout(function(){
			document.getElementById('noti').className = "noti animated slideOutRight";
			setTimeout(function(){
				document.getElementById('noti').style.display = "none";
			},400);
		},3000);
	}

	else if (code==5) {
		document.getElementById('notitext').innerHTML = "Missed few fields! Fill everything first!";
		document.getElementById('idk').src = "assets/images/cellphone.png";
		document.getElementById('noti').style.display = "block";
		document.getElementById('noti').className = "noti animated slideInRight";

		setTimeout(function(){
			document.getElementById('noti').className = "noti animated slideOutRight";
			setTimeout(function(){
				document.getElementById('noti').style.display = "none";
			},400);
		},3000);
	}

	else if (code==6) {
		document.getElementById('notitext').innerHTML = "Age out of range! Enter between 15-90 yrs!";
		document.getElementById('idk').src = "assets/images/cellphone.png";
		document.getElementById('noti').style.display = "block";
		document.getElementById('noti').className = "noti animated slideInRight";

		setTimeout(function(){
			document.getElementById('noti').className = "noti animated slideOutRight";
			setTimeout(function(){
				document.getElementById('noti').style.display = "none";
			},400);
		},3000);
	}

	else if (code==7) {
		document.getElementById('notitext').innerHTML = "Wrong information about gender! Enter (M/F) ";
		document.getElementById('idk').src = "assets/images/cellphone.png";
		document.getElementById('noti').style.display = "block";
		document.getElementById('noti').className = "noti animated slideInRight";

		setTimeout(function(){
			document.getElementById('noti').className = "noti animated slideOutRight";
			setTimeout(function(){
				document.getElementById('noti').style.display = "none";
			},400);
		},3000);
	}

	else if (code==8) {
		document.getElementById('notitext').innerHTML = "Height out of range! Enter between 120-230 cm!";
		document.getElementById('idk').src = "assets/images/cellphone.png";
		document.getElementById('noti').style.display = "block";
		document.getElementById('noti').className = "noti animated slideInRight";

		setTimeout(function(){
			document.getElementById('noti').className = "noti animated slideOutRight";
			setTimeout(function(){
				document.getElementById('noti').style.display = "none";
			},400);
		},3000);
	}

	else if (code==9) {
		document.getElementById('notitext').innerHTML = "Weight out of range! Enter between 30-130 Kg!";
		document.getElementById('idk').src = "assets/images/cellphone.png";
		document.getElementById('noti').style.display = "block";
		document.getElementById('noti').className = "noti animated slideInRight";

		setTimeout(function(){
			document.getElementById('noti').className = "noti animated slideOutRight";
			setTimeout(function(){
				document.getElementById('noti').style.display = "none";
			},400);
		},3000);
	}

	else if (code==10) {
		document.getElementById('notitext').innerHTML = "Wrong information about smoking! Enter (Y/N) ";
		document.getElementById('idk').src = "assets/images/cellphone.png";
		document.getElementById('noti').style.display = "block";
		document.getElementById('noti').className = "noti animated slideInRight";

		setTimeout(function(){
			document.getElementById('noti').className = "noti animated slideOutRight";
			setTimeout(function(){
				document.getElementById('noti').style.display = "none";
			},400);
		},3000);
	}

	else if (code==11) {
		document.getElementById('notitext').innerHTML = "Workout should be between 0-8hrs! Enter again.";
		document.getElementById('idk').src = "assets/images/cellphone.png";
		document.getElementById('noti').style.display = "block";
		document.getElementById('noti').className = "noti animated slideInRight";

		setTimeout(function(){
			document.getElementById('noti').className = "noti animated slideOutRight";
			setTimeout(function(){
				document.getElementById('noti').style.display = "none";
			},400);
		},3000);
	}

}



function showScreen(options)
{
	if(options==1)
	{
		document.getElementById('firstScreen').style.display="block";
		document.getElementById('secondScreen').style.display="none";
		document.getElementById('thirdScreen').style.display="none";
		document.getElementById('title').innerHTML="Home";
	}
	else if(options==2)
	{
		document.getElementById('firstScreen').style.display="none";
		document.getElementById('secondScreen').style.display="block";
		document.getElementById('thirdScreen').style.display="none";
		document.getElementById('title').innerHTML="Graphs";
	}
	else if(options==3)
	{
		document.getElementById('firstScreen').style.display="none";
		document.getElementById('secondScreen').style.display="none";
		document.getElementById('thirdScreen').style.display="block";
		document.getElementById('title').innerHTML="Time";
	}
	else{
		document.getElementById('proceed3').style.display = "block";
		document.getElementById('proceed3').className = "lowerBar animated slideInLeft";
	}
}


function clopro3f() {
	document.getElementById('proceed3').className = "lowerBar animated slideOutLeft";

	setTimeout(function(){
		document.getElementById('proceed3').style.display = "none";
	},300);

}

function showRegisterOption(){
	document.getElementById('proceed3').style.display = "block";
	document.getElementById('proceed3').className = "lowerBar animated slideInLeft"
	displayOptions();
}

/*setInterval(function(){
	var dataString = "";
	$.ajax({
				type: "GET",
				url: "http://10.131.126.24:3003/car?source=abc",
				data: dataString,
				cache: false,
				success: function(data) {
				},
				error: function(data)
				{
					noti(4);
				}
		});
}, 5000);*/


 function login() {
	 
	 if(document.getElementById('docbar').value==""){
				noti(5);
		}
	 else{
				localStorage.userName = document.getElementById('docbar').value;
				document.getElementById('appLoginScreen').className = "appLoginScreen animated fadeOut";
                document.getElementById('welcomeMessageScreen').style.display= "block";
                document.getElementById('hey').className = "animated fadeIn";
				document.getElementById('name').innerHTML = localStorage.userName ;

                setTimeout(function(){
              		document.getElementById('instructions').style.display = "block";
              	 	//document.getElementById('instructions').className = "instructions animated fadeIn";
              	},2000);

              	setTimeout(function(){
              		document.getElementById('appLoginScreen').style.display = "none";
					document.getElementById('welcomeMessageScreen').style.display= "none";
              	},3000);
/*
              	setTimeout(function(){
					//initialize();
              	},5000);*/
	 }
 }



var ab=1;
function nximg(){
	if(ab==1)
	{
		document.getElementById('disp').src = "assets/images/2.gif"
		document.getElementById('detail').innerHTML = "Don't worry it'll also help you getting Cardiologists and suggestions from them on the go!";
		ab++;
	}
	else if (ab==2) {
		document.getElementById('disp').src = "assets/images/3.gif"
		document.getElementById('detail').innerHTML = "So that you can enjoy your life without having the fear of any cardiovascular disease!";
		ab++;
	}
	else {
		ab=1;
		skip();
	}
}


function skip(){
	setTimeout(function(){
		document.getElementById('appLoginScreen').style.display = "none";
		document.getElementById('appMainScreen').style.display = "block";
		//document.getElementById('appMainScreen').className = "animated slideInLeft";
	},400);
}


function checkData(){
	var age = document.getElementById('age').value;
	var gender = document.getElementById('gender').value;
	var height = document.getElementById('height').value;
	var weight = document.getElementById('weight').value;
	var smoke = document.getElementById('smoke').value;
	var workout = document.getElementById('workout').value;
	
	localStorage.err=0;

	if(age=="" || gender=="" || height=="" || weight=="" || smoke=="" || workout=="")
	{
		noti(5);
	}

	else if(age>90 || age < 15){
		noti(6);
	}
	else if(gender!="m") {
		if(gender!="M") {
			if(gender!="f") {
				if(gender!="F") {
					noti(7);
					localStorage.err=1;
				}
			}
		}
	}
	else if(height>230 || height <120 ){
		noti(8);
	}

	else if(weight>130 || weight < 30){
		noti(9);
	}

	else if(smoke!="Y") {
		if(smoke!="y") {
			if(smoke!="n") {
				if(smoke!="N") {
					noti(10);
					localStorage.err=1;
				}
			}
		}
	}

	else if(workout>8 || workout < 0){
		noti(11);
	}

	if(localStorage.err!=1)
	{
		var risk =calculateRisk(age,gender,height,weight,smoke,workout);
		showRiskScreen(risk,age,gender,workout,smoke);
	}
}

function calculateRisk(age,gender,height,weight,smoke,workout){
	var bmi = calculateBmi(height,weight);
	bmi = Math.floor(bmi);
	var risk=5;

	if(bmi>28)
	{
		risk+=50;
		if(smoke=="Y")
		{
			risk+=20;
		}
		else if(smoke=="y")
			risk+=20;
		
		if(workout>5)
		{
			risk-=13;
		}
		
		if(gender=="f")
		{
			risk+=6;
		}
		else if(gender=="F")
			risk+=6;
	}

	else if(bmi>20 && bmi<24.5)
	{
		risk+=10;
		if(smoke=="Y")
		{
			risk+=19;
		}
		else if(smoke=="y")
			risk+=19;
		if(workout>5)
		{
			risk-=4;
		}
		if(gender=="f")
		{
			risk+=2;
		}
		else if(gender=="F")
			risk+=2;
	}

	else if(bmi>24.5 && bmi<28)
	{
		risk+=25;
		if(smoke=="Y")
		{
			risk+=23;
		}
		else if(smoke=="y")
			risk+=23;
		if(workout>3)
		{
			risk-=8;
		}
		if(gender=="f")
		{
			risk+=4;
		}
		else if(gender=="F")
			risk+=4;
	}

	else
	{
		if(smoke=="Y")
		{
			risk+=10;
		}
		else if(smoke=="y")
			risk+=10;
		if(workout>2)
		{
			risk-=2;
		}
	}

	return risk;

}

function calculateBmi(height,weight){
	height /= 100;
	var bmi = (weight/(height*height) );
	localStorage.bmi = bmi;
	return bmi;
}

function showRiskScreen(risk,age,gender,workout,smoke){
	localStorage.risk=risk;
	localStorage.dataFlag=1;
	document.getElementById('getData').style.display="none";
	document.getElementById('loader').style.display="block";
	setTimeout(function(){
			document.getElementById('loader').style.display = "none";
			document.getElementById('showRisk').style.display="block";
			showStatus(risk,age,gender,workout,smoke);
		},4000);

}

function showStatus(risk,gender,workout,smoke){
	localStorage.age=age;
	localStorage.gender=gender;
	localStorage.workout=workout;
	localStorage.smoke=smoke;
	
	if(risk<20)
	{
		document.getElementById('riskStatus').innerHTML="Good Job! Risk is Less!";
		document.getElementById('riskValue').innerHTML= risk+"%";
		
	}
	else if(risk>20 && risk<50)
	{
		document.getElementById('riskStatus').innerHTML="Start Working Out! Risk!";
		document.getElementById('riskValue').innerHTML= risk+"%";
	}
	else{
		document.getElementById('riskStatus').innerHTML="Attention! Very High Risk!";
		document.getElementById('riskValue').innerHTML= risk+"%";
	}
}

function showSecondScreenData(){
	
}

function lebhai(){
	document.getElementById('getData').style.display="block";
	document.getElementById('showRisk').style.display="none";
	showScreen(1);
	localStorage.dataFlag=0;
}